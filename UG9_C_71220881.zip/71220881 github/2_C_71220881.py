k=float(input("Masukkan Kecepatan Tempuh: "))
w=float(input("Masukkan Waktu Yang Diperlukan: "))

print ("Teman anda Mengisi Bensin Sebanyak 24 Liter")
print ("Biaya yang Dikeluarkan Untuk Mengisi Bensin Adalah Rp.360.000")
