nama = str(input("Masukkan nama anda: "))
mata_kuliah = str(input("Masukkan mata kuliah: "))
grup = str(input("Masukkan Grup: "))
print("Haloo! ",nama)
print(nama, "tergabung dalam kelas " + mata_kuliah, "pada grup ",grup)





